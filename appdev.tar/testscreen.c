//This file will be used to test functions in screen.c

#include <stdio.h>
#include <unistd.h>
#include "screen.h"


int main(void){
	Position cur = getscreensize();
	gotoXY (1,1);
	printf("Screen size, ROW=%d, COL=%d\n", cur.row, cur.col);
    printf("Press any key the screen will be  cleared\n");
    getchar();       //wait for the user to press the key
	getchar();
    for (int i=0; i<cur.row; i++){
        setcolors(RED, GREEN);
        clearscreen();
		float step =(float) cur.col/cur.row;
        gotoXY (i+1, step*i+1);
        printf("HELLO\n");
        usleep(250000);
}


/*}
    for (int i=1; i<20; i++){
        setcolors(RED, GREEN);
        setbgcolor(GREEN);
        clearscreen();
        gotoXY(i,20*4);
        printf("HELLO\n");
        usleep(250000);
}
    for (int i=20; i>1; i--){
        setcolors(RED, GREEN);
        clearscreen();
        gotoXY(20, i*4);
        printf("HELLO\n");
        usleep(250000);
}
    for (int i=15; i>1; i--){
        setcolors(RED, GREEN);
        setbgcolor(GREEN);
        clearscreen();
        gotoXY(i ,1);
        printf("HELLO\n");
        usleep(250000);
}
*/
   //  clearscreen();
    gotoXY(14, 35);
    setfgcolor(BLUE);
    printf("e1901100\n");
    getchar (); // wait for the user to pres a key
    drawbar(30, 30);
    drawbar(50, 30);

    getchar();
    resetcolors();
    printf("This line is back to default color\n");
}




